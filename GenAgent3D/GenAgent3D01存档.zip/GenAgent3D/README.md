# GenAgent3D: A Compositional LLM Agent for 3D Scene Generation

This project implements a novel LLM-based agent system for generating 3D scenes and animations from natural language instructions. The system features compositional reasoning, modular execution, and visual feedback loops.

## Key Features

- **Compositional Planning**: Hierarchical task decomposition using LLM
- **Modular Execution**: Atomic operations for scene manipulation
- **Memory & Tool Use**: Retrieval-augmented generation and API tool calling
- **Visual Feedback**: Render-and-verify mechanism for quality control

## Architecture

```
User Instruction → Planner Agent → Task Plan (Action Tree)
                       ↓
         (Memory / Tools / Retrieval)
                       ↓
    Executor Agent → API Calls (Scene Editor)
                       ↓
           Renderer → Visual Feedback
                       ↑
       Verifier Agent ← Feedback Evaluation
```

## Installation

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## Project Structure

```
GenAgent3D/
├── agents/                 # Agent implementations
│   ├── planner.py         # Task planning agent
│   ├── executor.py        # Scene execution agent
│   └── verifier.py        # Visual verification agent
├── core/                  # Core functionality
│   ├── memory.py         # Memory management
│   ├── tools.py          # Tool definitions
│   └── scene_graph.py    # Scene representation
├── renderers/            # Rendering backends
│   ├── blender.py       # Blender integration
│   └── unity.py         # Unity integration
├── utils/               # Utility functions
│   ├── prompts.py      # Prompt templates
│   └── visualization.py # Visualization tools
└── config/             # Configuration files
    └── default.yaml    # Default settings
```

## Usage

```python
from agents import PlannerAgent, ExecutorAgent, VerifierAgent

# Initialize agents
planner = PlannerAgent()
executor = ExecutorAgent()
verifier = VerifierAgent()

# Process instruction
instruction = "Create a cozy bedroom with a bed next to a window"
task_plan = planner.plan(instruction)
scene = executor.execute(task_plan)
is_valid = verifier.verify(scene, instruction)
```

## Research Value

This project addresses key challenges in LLM-based 3D scene generation:

1. **Compositionality**: Handling complex, multi-step instructions
2. **Generalization**: Out-of-distribution scene generation
3. **Consistency**: Maintaining structural coherence
4. **Feedback**: Visual verification and refinement

## Citation

If you use this code in your research, please cite:

```bibtex
@article{genagent3d2024,
  title={GenAgent3D: A Compositional LLM Agent for 3D Scene Generation},
  author={Your Name},
  journal={arXiv preprint},
  year={2024}
}
``` 