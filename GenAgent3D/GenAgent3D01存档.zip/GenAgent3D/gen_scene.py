import bpy

# 清空场景中的所有对象
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# 定义盒子的尺寸和位置
box_sizes = [(2, 2, 0.5), (1.5, 1.5, 0.4), (1, 1, 0.3)]  # (宽度, 长度, 高度)
box_positions = [(0, 0, 0.25), (0, 0, 0.25 + 0.5), (0, 0, 0.25 + 0.5 + 0.4)]  # (x, y, z)

# 创建三个盒子
for i, (size, position) in enumerate(zip(box_sizes, box_positions)):
    # 创建立方体
    bpy.ops.mesh.primitive_cube_add(size=1, location=position)
    cube = bpy.context.selected_objects[0]
    cube.name = f"Box_{i+1}"
    
    # 设置尺寸
    cube.dimensions = size

# 更新视图以显示更改
bpy.context.view_layer.update()