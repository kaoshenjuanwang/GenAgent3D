import os
import yaml
from pathlib import Path
from dotenv import load_dotenv
from agents.planner import PlannerAgent
from agents.executor import ExecutorAgent
from agents.verifier import VerifierAgent
from core.memory import SceneMemory
from core.script_generator import generate_blender_script
from openai import OpenAI
import base64

def load_config():
    """Load configuration from yaml file."""
    config_path = Path(__file__).parent / "config" / "config.yaml"
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def setup_blender():
    """Set up Blender environment."""
    import bpy
    # 设置Blender的Python路径
    blender_path = os.path.dirname(os.path.dirname(bpy.__file__))
    if blender_path not in os.environ["PATH"]:
        os.environ["PATH"] = blender_path + os.pathsep + os.environ["PATH"]

def generate_reasoning_and_script(task_desc, llm_client, model="qwen-plus"):
    prompt = f"""
你是一个3D场景推理与代码生成专家。请分两步完成任务：
1. 先详细推理用户需求，输出推理链（包括物体数量、类型、关系、空间布局、物理约束等）。
2. 再根据推理链，生成可直接在Blender中运行的Python脚本。
输出格式如下：
推理链:
...
Blender脚本:
```python
# 这里是完整代码
```
用户需求：{task_desc}
"""
    response = llm_client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}]
    )
    content = response.choices[0].message.content
    reasoning, script = "", ""
    if "Blender脚本:" in content:
        parts = content.split("Blender脚本:")
        reasoning = parts[0].replace("推理链:", "").strip()
        # 提取代码块
        if "```python" in parts[1]:
            script = parts[1].split("```python")[-1].split("```", 1)[0].strip()
        else:
            script = parts[1].strip()
    else:
        script = content
    return reasoning, script

def analyze_image_and_optimize_script(image_path, task_desc, script_content, llm_client, model="qwen-vl-max"):
    with open(image_path, "rb") as f:
        img_b64 = base64.b64encode(f.read()).decode("utf-8")
    prompt = f"""
你是一个3D场景优化专家。请分析下图是否符合如下描述，并给出改进建议（如物体遮挡、布局、光照、相机等）：
描述：{task_desc}
请输出：
1. 匹配度分数（0-100）
2. 存在的问题
3. 优化建议（可直接修改Python脚本的片段）
"""
    messages = [
        {"role": "user", "content": [
            {"type": "text", "text": prompt},
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_b64}"}}
        ]}
    ]
    response = llm_client.chat.completions.create(
        model=model,
        messages=messages
    )
    analysis = response.choices[0].message.content
    print("图片分析与建议：\n", analysis)
    return analysis

def main():
    user_input = input("请输入你的3D场景需求：")
    client = OpenAI(
        api_key="sk-e4beeb344fee48cd98a6d2b600fe15fa",
        base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    )
    reasoning, script = generate_reasoning_and_script(user_input, client, model="qwen-plus")
    print("推理链:\n", reasoning)
    with open("gen_scene.py", "w", encoding="utf-8") as f:
        f.write(script)
    print("Blender 脚本已保存到 gen_scene.py")
    print("请在Blender中运行 gen_scene.py，渲染后将图片反馈给系统。")
    image_path = input("请上传渲染图片的本地路径：").strip().strip('"').strip("'")
    analyze_image_and_optimize_script(image_path, user_input, script, client, model="qwen-vl-max")

if __name__ == "__main__":
    main() 