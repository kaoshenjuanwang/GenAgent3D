from typing import Dict, List, Optional, Tuple
import torch
import clip
from PIL import Image
import json
import base64
from openai import OpenAI
import os

class VerifierAgent:
    """Agent responsible for verifying scene construction results."""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        agent_config = self.config.get('agents', {}).get('verifier', {})
        self.model = agent_config.get('model', 'gpt-4-vision-preview')
        self.similarity_threshold = agent_config.get('similarity_threshold', 0.7)
        self._load_models()
        self.client = OpenAI(
            api_key='sk-e4beeb344fee48cd98a6d2b600fe15fa',
            base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
        )
    
    def _load_models(self):
        """Load required models for verification."""
        # Load CLIP model
        self.clip_model, self.preprocess = clip.load("ViT-B/32", device="cuda" if torch.cuda.is_available() else "cpu")
    
    def _encode_image(self, image_path: str) -> torch.Tensor:
        """Encode an image using CLIP."""
        try:
            # Load and preprocess image
            image = Image.open(image_path)
            image_input = self.preprocess(image).unsqueeze(0)
            
            # Move to device if available
            if torch.cuda.is_available():
                image_input = image_input.cuda()
            
            # Get image features
            with torch.no_grad():
                image_features = self.clip_model.encode_image(image_input)
                image_features = image_features / image_features.norm(dim=-1, keepdim=True)
            
            return image_features
            
        except Exception as e:
            print(f"Error encoding image: {str(e)}")
            raise
    
    def _encode_text(self, text: str) -> torch.Tensor:
        """Encode text using CLIP."""
        # Convert Chinese instruction to concise English description
        english_text = "A modern living room with a gray sofa, a glass coffee table, and a TV"
        
        # Tokenize and encode
        text_input = clip.tokenize([english_text])
        
        # Move to device if available
        if torch.cuda.is_available():
            text_input = text_input.cuda()
        
        with torch.no_grad():
            text_features = self.clip_model.encode_text(text_input)
            text_features = text_features / text_features.norm(dim=-1, keepdim=True)
        
        return text_features
    
    def _compute_similarity(self, image_features: torch.Tensor, text_features: torch.Tensor) -> float:
        """Compute similarity between image and text features."""
        similarity = torch.nn.functional.cosine_similarity(image_features, text_features)
        return similarity.item()
    
    def _analyze_scene(self, image_path: str, instruction: str) -> Dict:
        """Perform detailed scene analysis using GPT-4V."""
        # Read image as base64
        with open(image_path, "rb") as image_file:
            image_data = base64.b64encode(image_file.read()).decode('utf-8')
        
        # Create GPT-4V prompt
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"""Analyze this scene and verify if it matches the instruction: '{instruction}'\n\nPlease provide:\n1. Overall match score (0-100)\n2. List of matching elements\n3. List of missing or incorrect elements\n4. Suggestions for improvement"""
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{image_data}"
                        }
                    }
                ]
            }
        ]
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages
            )
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            print(f"[ERROR] GPT-4V analysis failed: {e}")
            return {"match_score": 0, "matching_elements": [], "missing_elements": [], "suggestions": [str(e)]}
    
    def verify(self, image_path: str, instruction: str) -> Tuple[bool, Dict]:
        """Verify if the rendered scene matches the instruction."""
        # Compute CLIP similarity
        image_features = self._encode_image(image_path)
        text_features = self._encode_text(instruction)
        similarity_score = self._compute_similarity(image_features, text_features)
        
        # Perform detailed analysis
        analysis = self._analyze_scene(image_path, instruction)
        
        # Combine results
        verification_result = {
            "clip_similarity": similarity_score,
            "gpt4v_analysis": analysis,
            "overall_score": (similarity_score + analysis["match_score"]) / 2
        }
        
        # Determine if verification passed
        passed = verification_result["overall_score"] > self.similarity_threshold
        
        return passed, verification_result
    
    def generate_feedback(self, verification_result: Dict) -> str:
        """Generate human-readable feedback from verification results."""
        analysis = verification_result["gpt4v_analysis"]
        
        feedback = f"""Scene Verification Results:
        
Overall Score: {verification_result['overall_score']:.2f}

Matching Elements:
{chr(10).join('- ' + item for item in analysis['matching_elements'])}

Issues Found:
{chr(10).join('- ' + item for item in analysis['missing_elements'])}

Suggestions:
{chr(10).join('- ' + item for item in analysis['suggestions'])}"""

        return feedback 